# Třísloupcový layout

Tento projekt obsahuje dvě verze layoutu:
- `flexbox/` – pomocí Flexboxu
- `grid/` – pomocí CSS Gridu

Každá složka má vlastní `index.html` a `style.css`.
